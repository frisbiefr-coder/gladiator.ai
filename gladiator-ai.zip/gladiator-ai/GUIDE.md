# 🚀 GUIDE DE DÉPLOIEMENT GLADIATOR AI

## ÉTAPE 1 — Configurer Supabase (5 min)

1. Aller sur supabase.com → votre projet "Gladiator.ai"
2. Cliquer sur **"SQL Editor"** dans le menu gauche
3. Copier-coller tout le contenu du fichier `supabase-setup.sql`
4. Cliquer **"Run"** → les tables sont créées ✅

## ÉTAPE 2 — Créer un compte GitHub (2 min)

1. Aller sur github.com
2. Créer un compte gratuit
3. Créer un nouveau repository appelé "gladiator-ai" (Public)
4. Uploader tous les fichiers du projet

## ÉTAPE 3 — Déployer sur Vercel (3 min)

1. Aller sur vercel.com → créer un compte gratuit
2. Cliquer "New Project" → importer depuis GitHub
3. Sélectionner "gladiator-ai"
4. Avant de déployer, ajouter les variables d'environnement :

| Nom | Valeur |
|-----|--------|
| FAL_KEY | 902e53b0-5610-43b2-ae18-acf5dcc77ba6:0f290ce6eb7f46a6f206a89e4c47250a |
| STRIPE_SECRET_KEY | sk_test_51TbJh2... (votre clé secrète Stripe) |
| STRIPE_WEBHOOK_SECRET | (voir étape 4) |
| SUPABASE_URL | https://sgrmbruwnswddulpdbic.supabase.co |
| SUPABASE_SERVICE_KEY | sb_secret_x1UACeE_-_uFQLkmJ5tC7A_UzeP51pu |

5. Cliquer **"Deploy"** ✅

## ÉTAPE 4 — Configurer le Webhook Stripe (5 min)

1. Aller sur dashboard.stripe.com → Développeurs → Webhooks
2. Cliquer "Ajouter un endpoint"
3. URL : `https://VOTRE-SITE.vercel.app/api/webhook`
4. Événements : sélectionner `checkout.session.completed`
5. Copier le "Signing secret" → l'ajouter dans Vercel comme `STRIPE_WEBHOOK_SECRET`

## ✅ VOTRE SITE EST EN LIGNE !

Les utilisateurs peuvent :
- Se créer un compte (3 crédits gratuits)
- Générer des images (1 crédit) et vidéos (3 crédits)
- Acheter des crédits via Stripe
- Voir leurs créations dans "Mes médias"
